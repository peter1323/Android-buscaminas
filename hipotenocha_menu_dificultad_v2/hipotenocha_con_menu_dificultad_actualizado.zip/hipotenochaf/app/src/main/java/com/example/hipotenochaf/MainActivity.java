package com.example.hipotenochaf;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
  private GridLayout g;
  /*private static int bombas;
  private  static int tamano;
  private static int tamanotablero;*/
  private boolean clicklargoboff;
  private boolean[] booleanmarca;// Array para rastrear las posiciones de las bombas
  private boolean[] celda_revelada;// Array para las celdas reveladas

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);


    //// Inicialización de gridlayout y matriz
    g = findViewById(R.id.g);
    //g.setColumnCount(8);
    //g.setRowCount(8);
    //para rastrear y saber la ubicacion de las bombas
   // booleanmarca = new boolean[144];
    //para saber la revelacion de botones/posiciones
    //celda_revelada = new boolean[144];

    // colocar bombas aleatorias, iniciar los botones
    //colocarBombas();
    //inicializarBotones();

    //metodo para reiniciar al darle al boton reiniciar
    //reinicio(null);

  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.menusdificultad, menu);
    return super.onCreateOptionsMenu(menu);
  }
////////////////////////////////////////////////////////////////////////////
  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    int id = item.getItemId();
    int tamanoTablero;
    int bombas;
    int buttonSize;

    if (id == R.id.facil) {
      g.removeAllViews();
      Toast.makeText(this, "Facil", Toast.LENGTH_SHORT).show();
      g.setColumnCount(8);
      g.setRowCount(8);
      bombas=5;
      buttonSize = 135;
      tamanoTablero = 64;
      booleanmarca = new boolean[64];
      celda_revelada = new boolean[64];
      //reinicio(null,bombas,buttonSize,tamanoTablero);
      colocarBombas(tamanoTablero,bombas);
      inicializarBotones(buttonSize);
      reiniciarJuego(bombas,buttonSize,tamanoTablero);

      //reinicio(null,bombas,buttonSize,tamanoTablero);
    } else if (id == R.id.medio) {
      g.removeAllViews();
      Toast.makeText(this, "Medio", Toast.LENGTH_SHORT).show();
      g.setColumnCount(12);
      g.setRowCount(12);
      bombas=10;
      tamanoTablero = 144;
      booleanmarca = new boolean[144];
      celda_revelada = new boolean[144];
      buttonSize = 90;
      colocarBombas(tamanoTablero,bombas);
      inicializarBotones(buttonSize);
      reiniciarJuego(bombas,buttonSize,tamanoTablero);
    } else if (id == R.id.dificil) {
      g.removeAllViews();
      Toast.makeText(this, "Dificil", Toast.LENGTH_SHORT).show();
      g.setColumnCount(16);
      g.setRowCount(16);
      tamanoTablero = 256;
      booleanmarca = new boolean[256];
      celda_revelada = new boolean[256];
      buttonSize = 70;
      bombas=20;
      colocarBombas(tamanoTablero,bombas);
      inicializarBotones(buttonSize);
      reiniciarJuego(bombas,buttonSize,tamanoTablero);
    }
    return super.onOptionsItemSelected(item);
  }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // metodo para colocar las bombas en posiciones aleatorias
  private void colocarBombas(int tamanoTablero,int bombas) {
    Random random = new Random();
    int cantidadHipotenochas = 0;

    while (cantidadHipotenochas < bombas) {
      int ubicacion = random.nextInt(tamanoTablero);

      // Asegurarse de que booleanmarca esté inicializado
      /*if (booleanmarca == null) {
        booleanmarca = new boolean[144];
      }*/

      //verificar si la ubicación ya está marcada como bomba para que no la vuelva a usar
      if (!booleanmarca[ubicacion]) {
        //System.out.println("Bomba enn " + ubicacion);
        booleanmarca[ubicacion] = true;
        cantidadHipotenochas++;
      }
    }

  }

  // metodo para inicializar los botones en el gridlayout
  private void inicializarBotones(int tamano) {
    for (int i = 0; i < g.getColumnCount() * g.getRowCount(); i++) {
      //variable tamaño botones
      int buttonSize = tamano;


      //redimensionar botones
      ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(buttonSize, buttonSize);

      // Crear botones según las bombas en la posición
      if (booleanmarca[i]) {
        // Botón con bomba (ImageButton)
        ImageButton bi = new ImageButton(this);
        bi.setId(i);
        bi.setLayoutParams(params);

        // Variable para indicar si se ha colocado una bandera
        final boolean[] banderaColocada = {false};

        // Manejar clic en botones con bomba
        int finalI = i;
        bi.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

            if (!banderaColocada[0]) {
              revelarCelda(finalI);
              bi.setImageResource(R.drawable.darkvader);
            }
          }
        });

        // Manejar clic largo en botones con bomba para colocar/quitar una bandera
        bi.setOnLongClickListener(new View.OnLongClickListener() {
          @Override
          public boolean onLongClick(View v) {
            if (!banderaColocada[0]) {
              // Colocar la bandera
              bi.setImageResource(R.drawable.bandera); // Reemplaza con el recurso de imagen de bandera
              banderaColocada[0] = true;
            } else {
              // Quitar la bandera
              bi.setImageResource(0); // O setea a null, dependiendo de tus recursos
              banderaColocada[0] = false;
            }
            return true; // Indicar que el evento ha sido manejado
          }
        });
        g.addView(bi);
      } else {
        // Botón sin bomba (Button)
        int b = i;
        Button b1 = new Button(this);
        b1.setId(i);
        b1.setLayoutParams(params);
        b1.setOnLongClickListener(new View.OnLongClickListener() {
          @Override
          public boolean onLongClick(View v) {
            if (b1.getText().equals("\uD83D\uDEA9")){
              b1.setText("");
            } else {
              b1.setText("\uD83D\uDEA9");
            }
            clicklargoboff = true;
            return true;
          }
        });

        // Manejar clic en botones sin bomba
        b1.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (b1.getText().equals("\uD83D\uDEA9"))
              return;
            if (!clicklargoboff){
              revelarCelda(b);
              int bombavecino = contarBombasCercanas(b);

              if (bombavecino >= 0) {
                //print para saber donde estan las bombas
                //b1.setText(String.valueOf(bombavecino));
              }
            } else {
              clicklargoboff = false;
            }


          }
        });
        g.addView(b1);
      }
    }
  }


  // metodo para contar el número de bombas en las celdas cercanas
  private int contarBombasCercanas(int index) {
    int count = 0;
    // calcular la fila y la columna de la posicion actual
    int row = index / g.getRowCount();
    int col = index % g.getColumnCount();
    // La variable 'i' representa las filas adyacentes
    for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, g.getRowCount() - 1); i++) {
      // La variable 'j' representa las columnas adyacentes
      for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, g.getColumnCount() - 1); j++) {
        // Calcular el índice de la celda adyacente en la matriz
        int indicevecino = i * g.getColumnCount() + j;

        // verificar si la celda adyacente contiene una bomba
        if (booleanmarca[indicevecino]) {
          count++;//incrementar el contador de bombas cercanas
        }
      }
    }

    return count; //Devolver el número total de bombas cercanas
  }


  // metodo para revelar una celda
  private void revelarCelda(int index) {

    //Este if es para evitar revelar la misma celda dos veces
    if (celda_revelada[index]) {
      return;
    }

    celda_revelada[index] = true;

    // verificar si la celda contiene una bomba
    if (booleanmarca[index]) {
      // mostrar mensaje de fin de juego, porque se hizo clic en una bomba
      Toast.makeText(this, "¡Has perdido! Has hecho clic en una bomba.", Toast.LENGTH_SHORT).show();
      //al perder este metodo mostrarbombas te muestra las bombas
      mostrarBombas();
      //deshabilita los botones al perder para que no puedas seguir jugando
      deshabilitarTodosLosBotones();
      return;
    }
    // obtener el botón correspondiente a la celda de la matriz
    Button button = (Button) g.getChildAt(index);

    // contar el número de bombas cercanas
    int bombavecina = contarBombasCercanas(index);
    if (bombavecina > 0) {
      button.setText(String.valueOf(bombavecina));
      button.setEnabled(false); // Desactivar el botón después de revelar cuantas bombas tiene alrededor
    } else {
      // si no hay bombas cercanas, revelar las celdas adyacentes de forma recursiva y los botones descubiertos se desactivan
      revelarCeldasAdyacentes(index);
      button.setBackgroundColor(Color.BLACK);
      button.setEnabled(false);
    }
    // comprobar cuando ganes después de revelar una celda
    if (todasLasCeldasSinBombasReveladas()) {
      // mostrar mensaje al ganar
      Toast.makeText(this, "¡Felicidades! Has ganado.", Toast.LENGTH_SHORT).show();
      //te muestra las bombas
      mostrarBombas();
      //deshabilita los botones para uqe no puedas seguir jugando
      deshabilitarTodosLosBotones();

    }

  }

  // metodo para verificar si todas las celdas sin bombas han sido reveladas
  private boolean todasLasCeldasSinBombasReveladas() {
    for (int i = 0; i < celda_revelada.length; i++) {
      //verificar si la celda actual no tiene una bomba y no ha sido revelada
      if (!booleanmarca[i] && !celda_revelada[i]) {
        return false; // comprueba si es una celda sin bomba que no ha sido revelada, devolvemos false
      }
    }
    // Si todas las celdas sin bombas han sido reveladas, devolvemos true
    return true;
  }

  // metodo para mostrar las bombas después de perder o ganar
  private void mostrarBombas() {
    for (int i = 0; i < g.getChildCount(); i++) {
      View view = g.getChildAt(i);
      // cmporbar si la vista actual es un imagebutton
      if (view instanceof ImageButton) {
        ImageButton imageButton = (ImageButton) view;
        // comprobar si la posicion actual contiene una bomba
        if (booleanmarca[i]) {
          imageButton.setImageResource(R.drawable.darkvader); // Cambia la imagen para mostrar la bomba
        }
      }
    }
  }

  // metodo para deshabilitar todos los botones después de perder o ganar
  private void deshabilitarTodosLosBotones() {
    for (int i = 0; i < g.getChildCount(); i++) {
      View view = g.getChildAt(i);
      if (view instanceof Button) {
        Button button = (Button) view;
        // Deshabilitar el boton
        button.setEnabled(false);
      }else if (view instanceof ImageButton) {
        ImageButton imageButton = (ImageButton) view;
        // Deshabilitar el imagebutton
        imageButton.setEnabled(false);
      }
    }
  }

  // metodo para revelar celdas adyacentes de forma recursiva
  private void revelarCeldasAdyacentes(int index) {
    // Calcular la fila y columna de la posicon actual en el gridlayout
    int row = index / g.getRowCount();
    int col = index % g.getColumnCount();
    //sobre filas
    for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, g.getRowCount() - 1); i++) {
      //sobre columnas
      for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, g.getColumnCount() - 1); j++) {

        int indicevecina = i * g.getColumnCount() + j;
        //llamar al metodo revelar celda para que funcione la recursividad y revelar las celdas
        revelarCelda(indicevecina);
      }
    }
  }

  // metodo para reiniciar el juego
  private void reiniciarJuego(int bombas,int tamano,int tamanotablero) {
    // Restablecer variables
    //booleanmarca = new boolean[144];
    //celda_revelada = new boolean[144];

    // limpiar el gridlayout
    g.removeAllViews();

    //colocar otra vez bombas
    colocarBombas(tamanotablero,bombas);

    // volver a inicializar botones
    inicializarBotones(tamano);
  }

  // metodo para gestionar el botón de reinicio y que utilice el metodo para reinicar el juego
  /*public void reinicio(View view,int bombas,int tamano,int tamanotablero) {
    Button reiniciarButton = findViewById(R.id.btnreiniciar);
    reiniciarButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        reiniciarJuego(bombas,tamano,tamanotablero);
      }
    });
  }*/
}