package com.example.hipotenochaf;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
  private GridLayout g;
  private boolean[] booleanmarca;// Array para rastrear las posiciones de las bombas
  private boolean[] celda_revelada;// Array para las celdas reveladas

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);


    //// Inicialización de gridlayout y matriz
    g = findViewById(R.id.g);
    g.setColumnCount(8);
    g.setRowCount(8);
    //para rastrear y saber la ubicacion de las bombas
    booleanmarca = new boolean[64];
    //para saber la revelacion de botones/posiciones
    celda_revelada = new boolean[64];

    // colocar bombas aleatorias, iniciar los botones
    colocarBombas();
    inicializarBotones();

    //metodo para reiniciar al darle al boton reiniciar
    reinicio(null);

  }

  // metodo para colocar las bombas en posiciones aleatorias
  private void colocarBombas() {
    Random random = new Random();
    int cantidadHipotenochas = 0;

    while (cantidadHipotenochas < 10) {
      int ubicacion = random.nextInt(64);

      // Asegurarse de que booleanmarca esté inicializado
      if (booleanmarca == null) {
        booleanmarca = new boolean[64];
      }

      //verificar si la ubicación ya está marcada como bomba para que no la vuelva a usar
      if (!booleanmarca[ubicacion]) {
        //System.out.println("Bomba enn " + ubicacion);
        booleanmarca[ubicacion] = true;
        cantidadHipotenochas++;
      }
    }

  }

  // metodo para inicializar los botones en el gridlayout
  private void inicializarBotones() {
    for (int i = 0; i < g.getColumnCount() * g.getRowCount(); i++) {
      //variable tamaño botones
      int buttonSize = 135;


      //redimensionar botones
      ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(buttonSize, buttonSize);

      // Crear botones según las bombas en la posición
      if (booleanmarca[i]) {
        // Botón con bomba (ImageButton)
        ImageButton bi = new ImageButton(this);
        bi.setId(i);
        bi.setLayoutParams(params);

        // Manejar clic en botones con bomba
        int finalI = i;
        bi.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
          revelarCelda(finalI);
            bi.setImageResource(R.drawable.darkvader);
          }
        });
        g.addView(bi);
      } else {
        // Botón sin bomba (Button)
        int b = i;
        Button b1 = new Button(this);
        b1.setId(i);
        b1.setLayoutParams(params);

        // Manejar clic en botones sin bomba
        b1.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            revelarCelda(b);
            int bombavecino = contarBombasCercanas(b);

            if (bombavecino >= 0) {
              //print para saber donde estan las bombas
              //b1.setText(String.valueOf(bombavecino));
            }

          }
        });
        g.addView(b1);
      }
    }
  }

  // metodo para contar el número de bombas en las celdas cercanas
  private int contarBombasCercanas(int index) {
    int count = 0;
    // calcular la fila y la columna de la posicion actual
    int row = index / g.getRowCount();
    int col = index % g.getColumnCount();
    // La variable 'i' representa las filas adyacentes
    for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, g.getRowCount() - 1); i++) {
      // La variable 'j' representa las columnas adyacentes
      for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, g.getColumnCount() - 1); j++) {
        // Calcular el índice de la celda adyacente en la cuadrícula
        int indicevecino = i * g.getColumnCount() + j;

        // verificar si la celda adyacente contiene una bomba
        if (booleanmarca[indicevecino]) {
          count++;//incrementar el contador de bombas cercanas
        }
      }
    }

    return count; //Devolver el número total de bombas cercanas
  }
  // metodo para revelar una celda
  private void revelarCelda(int index) {

    //Este if es para evitar revelar la misma celda dos veces
    if (celda_revelada[index]) {
      return;
    }

    celda_revelada[index] = true;

    // verificar si la celda contiene una bomba
    if (booleanmarca[index]) {
      // mostrar mensaje de fin de juego, porque se hizo clic en una bomba
      Toast.makeText(this, "¡Has perdido! Has hecho clic en una bomba.", Toast.LENGTH_SHORT).show();
      //al perder este metodo mostrarbombas te muestra las bombas
      mostrarBombas();
      //deshabilita los botones al perder para que no puedas seguir jugando
      deshabilitarTodosLosBotones();
      return;
    }
    // obtener el botón correspondiente a la celda de la matriz
    Button button = (Button) g.getChildAt(index);

    // contar el número de bombas cercanas
    int bombavecina = contarBombasCercanas(index);
    if (bombavecina > 0) {
      button.setText(String.valueOf(bombavecina));
      button.setEnabled(false); // Desactivar el botón después de revelar cuantas bombas tiene alrededor
    } else {
      // si no hay bombas cercanas, revelar las celdas adyacentes de forma recursiva y los botones descubiertos se desactivan
      revelarCeldasAdyacentes(index);
      button.setEnabled(false);
    }
    // comprobar cuando ganes después de revelar una celda
    if (todasLasCeldasSinBombasReveladas()) {
      // mostrar mensaje al ganar
      Toast.makeText(this, "¡Felicidades! Has ganado.", Toast.LENGTH_SHORT).show();
      //te muestra las bombas
      mostrarBombas();
      //deshabilita los botones para uqe no puedas seguir jugando
      deshabilitarTodosLosBotones();

    }

  }

  // metodo para verificar si todas las celdas sin bombas han sido reveladas
  private boolean todasLasCeldasSinBombasReveladas() {
    for (int i = 0; i < celda_revelada.length; i++) {
      //verificar si la celda actual no tiene una bomba y no ha sido revelada
      if (!booleanmarca[i] && !celda_revelada[i]) {
        return false; // comprueba si es una celda sin bomba que no ha sido revelada, devolvemos false
      }
    }
    // Si todas las celdas sin bombas han sido reveladas, devolvemos true
    return true;
  }

  // metodo para mostrar las bombas después de perder o ganar
  private void mostrarBombas() {
    for (int i = 0; i < g.getChildCount(); i++) {
      View view = g.getChildAt(i);
      // cmporbar si la vista actual es un imagebutton
      if (view instanceof ImageButton) {
        ImageButton imageButton = (ImageButton) view;
        // comprobar si la posicion actual contiene una bomba
        if (booleanmarca[i]) {
          imageButton.setImageResource(R.drawable.darkvader); // Cambia la imagen para mostrar la bomba
        }
      }
    }
  }

  // metodo para deshabilitar todos los botones después de perder o ganar
  private void deshabilitarTodosLosBotones() {
    for (int i = 0; i < g.getChildCount(); i++) {
      View view = g.getChildAt(i);
      if (view instanceof Button) {
        Button button = (Button) view;
        // Deshabilitar el boton
        button.setEnabled(false);
      }else if (view instanceof ImageButton) {
        ImageButton imageButton = (ImageButton) view;
        // Deshabilitar el imagebutton
        imageButton.setEnabled(false);
      }
    }
  }

  // metodo para revelar celdas adyacentes de forma recursiva
  private void revelarCeldasAdyacentes(int index) {
    // Calcular la fila y columna de la posicon actual en el gridlayout
    int row = index / g.getRowCount();
    int col = index % g.getColumnCount();
    //sobre filas
    for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, g.getRowCount() - 1); i++) {
      //sobre columnas
      for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, g.getColumnCount() - 1); j++) {

        int indicevecina = i * g.getColumnCount() + j;
        //llamar al metodo revelar celda para que funcione la recursividad y revelar las celdas
        revelarCelda(indicevecina);
      }
    }
  }

  // metodo para reiniciar el juego
  private void reiniciarJuego() {
    // Restablecer variables
    booleanmarca = new boolean[64];
    celda_revelada = new boolean[64];

    // limpiar el gridlayout
    g.removeAllViews();

    //colocar otra vez bombas
    colocarBombas();

    // volver a inicializar botones
    inicializarBotones();
  }

  // metodo para gestionar el botón de reinicio y que utilice el metodo para reinicar el juego
  public void reinicio(View view) {
    Button reiniciarButton = findViewById(R.id.btnreiniciar);
    reiniciarButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        reiniciarJuego();
      }
    });
  }
}